export default function MediaGallery() {
  const videos = [
    { title: "Video-1", src: "https://www.w3schools.com/html/mov_bbb.mp4" },
    { title: "Video-2", src: "https://samplelib.com/lib/preview/mp4/sample-5s.mp4" },
    { title: "Video-3", src: "https://www.w3schools.com/html/movie.mp4" },
  ];

  const audios = [
    { title: "English Pronunciation Practice", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { title: "History - World War II Overview", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
    { title: "Coding Concepts Explained", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold">Media Gallery</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Learn through study-related videos and audios
        </p>
      </div>

      {/* Videos Section */}
      <div>
        <h3 className="text-xl font-semibold mb-4">Videos</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {videos.map((video, idx) => (
            <div
              key={idx}
              className="p-4 bg-gray-100 dark:bg-gray-800 rounded shadow"
            >
              <h4 className="font-medium mb-2">{video.title}</h4>
              <video controls className="w-full rounded">
                <source src={video.src} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>
          ))}
        </div>
      </div>

      {/* Audios Section */}
      <div>
        <h3 className="text-xl font-semibold mb-4">Audios</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {audios.map((audio, idx) => (
            <div
              key={idx}
              className="p-4 bg-gray-100 dark:bg-gray-800 rounded shadow"
            >
              <h4 className="font-medium mb-2">{audio.title}</h4>
              <audio controls className="w-full">
                <source src={audio.src} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}