export default function Dashboard() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Dashboard</h2>

      <div className="mb-4">
        <p>Course Progress:</p>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div className="bg-green-500 h-4 rounded-full w-2/3"></div>
        </div>
        <p className="text-sm mt-1">66% completed</p>
      </div>

      <div>
        <p className="font-semibold">Recent Activity</p>
        <ul className="list-disc ml-5 text-sm">
          <li>Watched: React Basics</li>
          <li>Completed: Quiz 1</li>
        </ul>
      </div>
    </div>
  );
}