import { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Gallery from "./pages/Gallery";
import Cart from "./pages/Cart";
import Signup from "./pages/Signup";

export default function App() {
  const [darkMode, setDarkMode] = useState(
    localStorage.getItem("theme") === "dark"
  );

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  return (
    <Router>
      <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
        {/* Navbar */}
        <nav className="flex items-center justify-between p-4 shadow-md bg-gray-200 dark:bg-gray-800">
          <h1 className="text-xl font-bold">EduStream</h1>
          <div className="flex gap-4">
            <Link to="/" className="hover:text-blue-500">Home</Link>
            <Link to="/gallery" className="hover:text-blue-500">Gallery</Link>
            <Link to="/cart" className="hover:text-blue-500">Cart</Link>
            <Link to="/signup" className="hover:text-blue-500">Sign Up</Link>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-3 py-1 rounded bg-gray-700 text-white dark:bg-yellow-500"
          >
            {darkMode ? "Light" : "Dark"}
          </button>
        </nav>

        {/* Pages */}
        <main className="p-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/signup" element={<Signup />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}