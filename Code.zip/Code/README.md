# Introduction

This is a modern online learning platform prototype built with React, Vite, and Tailwind CSS.
This prototype demonstrates key features of an e-learning system, including:

- Media Gallery (sample videos, audios) 
- Dark Mode with saved user preference
- Shopping Cart for course purchases
- Signup Form with real-time validation

## Installation & Setup

##  1.Clone the repository

- git clone https://github.com/Gaurvi-P/Assignment_1(AFWD).git
    cd assignment1

## Install dependencies

- npm install

## Run the development server

- npm run dev


## Open in browser:

- http://localhost:5173
