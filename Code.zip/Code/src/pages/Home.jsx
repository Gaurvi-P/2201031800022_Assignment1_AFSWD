export default function Home() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold">Dashboard</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Track your learning progress here
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="p-4 bg-blue-100 dark:bg-blue-900 rounded shadow text-center">
          <h3 className="font-semibold">Courses</h3>
          <p className="text-2xl font-bold">3</p>
        </div>
        <div className="p-4 bg-green-100 dark:bg-green-900 rounded shadow text-center">
          <h3 className="font-semibold">Progress</h3>
          <p className="text-2xl font-bold">72%</p>
        </div>
        <div className="p-4 bg-yellow-100 dark:bg-yellow-900 rounded shadow text-center">
          <h3 className="font-semibold">Quizzes</h3>
          <p className="text-2xl font-bold">5</p>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded shadow">
        <h3 className="font-semibold mb-2">Recent Activity</h3>
        <ul className="list-disc pl-5 space-y-1">
          <li>Completed "React Basics"</li>
          <li>Watched a lecture on Tailwind</li>
          <li>Attempted JavaScript Quiz</li>
        </ul>
      </div>
    </div>
  );
}
