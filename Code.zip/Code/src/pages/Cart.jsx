import { useState } from "react";

export default function Cart() {
  const courses = [
    { id: 1, title: "React Basics", price: 29 },
    { id: 2, title: "Tailwind Mastery", price: 19 },
    { id: 3, title: "Fullstack with Laravel", price: 49 },
  ];

  const [cart, setCart] = useState([]);

  const addToCart = (course) => {
    if (!cart.find((c) => c.id === course.id)) {
      setCart([...cart, course]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((c) => c.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-10 px-4">
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
        {/* Courses Section */}
        <div className="bg-white dark:bg-gray-800 shadow-lg rounded-xl p-6">
          <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
            📚 Available Courses
          </h3>
          <div className="space-y-4">
            {courses.map((course) => (
              <div
                key={course.id}
                className="flex justify-between items-center p-4 border rounded-lg hover:shadow-md transition dark:border-gray-700"
              >
                <span className="text-gray-800 dark:text-gray-200 font-medium">
                  {course.title}{" "}
                  <span className="text-gray-500 dark:text-gray-400 text-sm">
                    (${course.price})
                  </span>
                </span>
                <button
                  onClick={() => addToCart(course)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
                >
                  Add
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Cart Section */}
        <div className="bg-white dark:bg-gray-800 shadow-lg rounded-xl p-6">
          <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
            🛒 Your Cart
          </h3>
          {cart.length === 0 ? (
            <p className="text-gray-600 dark:text-gray-400">No items yet.</p>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex justify-between items-center p-4 border rounded-lg hover:shadow-md transition dark:border-gray-700"
                >
                  <span className="text-gray-800 dark:text-gray-200 font-medium">
                    {item.title}
                  </span>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg transition"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <div className="pt-4 border-t dark:border-gray-700">
                <p className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                  Total: $
                  {cart.reduce((sum, item) => sum + item.price, 0).toFixed(2)}
                </p>
                <button className="mt-3 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition">
                  Checkout
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}